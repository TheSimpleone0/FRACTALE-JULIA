var searchData=
[
  ['rgb',['RGB',['../class_r_g_b.html',1,'']]]
];
