var searchData=
[
  ['readme',['README',['../md_README.html',1,'']]],
  ['rgb',['RGB',['../class_r_g_b.html',1,'']]]
];
